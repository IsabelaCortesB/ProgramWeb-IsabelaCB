import { Outlet } from 'react-router-dom';

const Layout = () => <Outlet />;

export default Layout;
