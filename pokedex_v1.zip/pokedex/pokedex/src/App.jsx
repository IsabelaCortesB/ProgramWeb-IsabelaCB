import './App.css'
import { Pokedex } from './pages/Pokedex'

function App() {

  return (
    <h1 className="">
      <Pokedex />
    </h1>
  )
}

export default App
